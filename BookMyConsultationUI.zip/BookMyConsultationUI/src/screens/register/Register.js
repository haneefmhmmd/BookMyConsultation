import React, { useState } from "react";
import Form from "../../common/Form";
import Toast from "../../common/Toast";
import { useContextData } from '../../common/context/ContextProvider';

export default function Register({ modalCloseHandler }) {
  const [isRegisterSuccess, setIsRegisterSuccess] = useState(null);
  const { setIsLoggedIn,setUser } = useContextData();
  const fieldList = [
    {
      label: "First Name",
      name: "firstName",
      value: "",
      type: "text",
    },
    {
      label: "Last Name",
      name: "lastName",
      value: "",
      type: "text",
    },
    {
      label: "Email",
      name: "emailId",
      value: "",
      type: "text",
    },
    {
      label: "Password",
      name: "password",
      value: "",
      type: "password",
    },
    {
      label: "Mobile No.",
      name: "mobile",
      value: "",
      type: "tel",
    },
  ];

  const hideToastMesage =()=>{
    setTimeout(()=>{
      setIsRegisterSuccess(null);
    },1500)
  }

  const loginUser = async(email,password) => {
    const loginRequest = await fetch("http://localhost:8080/auth/login", {
        method: "POST",
        headers: {
          Authorization: "Basic " + btoa(email + ":" + password),
        },
      });
      const loginResponse = await loginRequest.json();
      if (loginRequest.status === 200) {
        window.accessToken = loginResponse.accessToken;
        setUser(loginResponse);
        setIsLoggedIn(true);
        modalCloseHandler(true);
      }else{
        console.error("Error while logging in");
      }
  }

  const onSubmitHandler = async (inputs) => {
    const rawData = {};
    inputs.forEach((input) => {
      rawData[input.name] = input.value;
    });
    rawData.dob = "";
      console.log("Registering");
      const request = await fetch("http://localhost:8080/users/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(rawData),
      });
      const response = await request.json();
      if(request.status === 200){
        console.log("Registering successful");
        setIsRegisterSuccess(true);
        loginUser(rawData.emailId,rawData.password);
      }
      if(request.status !== 200){
        console.log("Registering unsuccessful");
        setIsRegisterSuccess(false);
        hideToastMesage();
      }
  };
  return (
    <>
      <Form
        fieldList={fieldList}
        submitButtonText="REGISTER"
        onSubmitHandler={onSubmitHandler}
      />
      {isRegisterSuccess && <Toast type="success" message="Registration Successful, Loggin you in!" />}
      {isRegisterSuccess === false && <Toast type="error" message="Error while Registering!" />}
    </>
  );
}
