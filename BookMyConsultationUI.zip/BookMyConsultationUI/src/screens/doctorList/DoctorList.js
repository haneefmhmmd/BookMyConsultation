import React from "react";
import { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";

import { Box } from "@material-ui/core";
import DoctorSpecialityDropDown from "./DoctorSpecialityDropdown";
import BookAppointment from "./BookAppointment";
import DoctorDetails from "./DoctorDetails";
import Rating from "../../common/Rating";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "40%",
    margin: "16px auto",
    padding: 16,
    "& h6": {
      marginBottom: 32,
      fontWeight: "normal",
    },
    "& p": {
      marginTop: 8,
    },
    "& .btn-grp": {
      marginTop: 8,
    },
    "& button": {
      width: "40%",
    },
    "& button:first-child": {
      marginRight: 10,
    },
    "& button:last-child": {
      backgroundColor: "green",
    },
  }
}));

export default function DoctorList() {
  const classes = useStyles();
  const [doctorList, setDoctorList] = useState(null);
  const [selectedSpecality, setSelectedSpecality] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState({});
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      const fetchData = await fetch(
        `http://localhost:8080/doctors?speciality=${selectedSpecality}`
      );
      const data = await fetchData.json();
      setDoctorList(data);
    };
    fetchData();
  }, [selectedSpecality]);
  const handleSpecialityChange = (selectedValue) => {
    setSelectedSpecality(selectedValue);
  };

  const bookAppointmentBtnHandler = (doctor) => {
    setSelectedDoctor(doctor);
    setIsAppointmentModalOpen(true);
  };

  const viewDetailsBtnHandler = (doctor) => {
    setSelectedDoctor(doctor);
    setIsDetailsModalOpen(true);
  };

  return (
    <section>
      <Box mx="auto" textAlign="center">
        <DoctorSpecialityDropDown
          selectedSpecality={selectedSpecality}
          updateSpecialityHander={handleSpecialityChange}
        />
      </Box>
      {doctorList &&
        doctorList.map((doctor) => {
          return (
            <Paper className={classes.root} key={doctor.id}>
              <Typography variant="h6">
                Doctor Name : {doctor.firstName} {doctor.lastName}
              </Typography>
              <Typography variant="body1">
                Speciality : {doctor.speciality}
              </Typography>
              <div className="fx fx--ac">
                <Typography variant="body1" component="span">
                  Rating :
                </Typography>
                <Rating rating={doctor.rating} />
              </div>
              <div className="btn-grp">
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => {
                    bookAppointmentBtnHandler(doctor);
                  }}
                >
                  BOOK APPOINTMENT
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => {
                    viewDetailsBtnHandler(doctor);
                  }}
                >
                  VIEW DETAILS
                </Button>
              </div>
            </Paper>
          );
        })}
      {isAppointmentModalOpen && (
        <BookAppointment
          doctor={selectedDoctor}
          modalOpen = {isAppointmentModalOpen}
          bookApptModalHandler={() => {
            setIsAppointmentModalOpen(false);
          }}
        />
      )}
      {isDetailsModalOpen && (
        <DoctorDetails
          doctor={selectedDoctor}
          modalOpen = {isDetailsModalOpen}
          viewDetailsModalHandler={() => {
            setIsDetailsModalOpen(false);
          }}
        />
      )}
    </section>
  );
}
