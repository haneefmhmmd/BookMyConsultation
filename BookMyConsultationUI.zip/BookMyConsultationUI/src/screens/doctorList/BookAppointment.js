import { Modal } from "@material-ui/core";
import React, { useEffect, useState,useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import { CardContent, CardHeader } from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import Button from "@material-ui/core/Button";

import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import uuid from "react-uuid";
import { useContextData } from "../../common/context/ContextProvider";

const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 560,
    width: "100%",
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%,-50%)",
  },
  header: {
    backgroundColor: "purple",
    height: 70,
    display: "flex",
    alignItems: "center",
    padding: 11,
    color: "white",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    padding: "16px",
    "& > * ": {
      marginTop: theme.spacing(2),
    },
    "& > :first-child": {
      marginTop: 0,
    },
  },
  submitBtn: {
    width: "fit-content",
    marginTop: 24,
  },
}));

export default function BookAppointment({
  doctor,
  modalOpen,
  bookApptModalHandler,
}) {
  const classes = useStyles();
  const { user } = useContextData();
  const cardComponentRef = useRef(null);
  const [appointmentDetails, setAppointmentDetails] = useState({
    doctorId: doctor.id,
    doctorName: `${doctor.firstName} ${doctor.lastName}`,
    userId: user.id,
    userName: `${user.firstName} ${user.lastName}`,
    userEmailId: user.emailAddress,
    timeSlot: "",
    appointmentDate: new Date().toISOString().split("T")[0],
    createdDate: "",
    symptoms: "",
    priorMedicalHistory: "",
  });
  const [timeSlots, setTimeSlots] = useState([]);

  const [isTimeSlotNotChosen, setIsTimeSlotNotChosen] = useState(null);

  const handleDateChange = (date) => {
    setAppointmentDetails({
      ...appointmentDetails,
      appointmentDate: date.toISOString().split("T")[0],
    });
  };

  useEffect(() => {
    const fetchData = async () => {
      const req = await fetch(
        `http://localhost:8080/doctors/${doctor.id}/timeSlots?date=${appointmentDetails.appointmentDate}`
      );
      const data = await req.json();
      setTimeSlots(data.timeSlot);
    };
    fetchData();
  }, [doctor.id, appointmentDetails.appointmentDate]);

  const onTimeSlotChangeHandler = (e) => {
    if (appointmentDetails.timeSlot === "" && e.target.value !== "") {
      setIsTimeSlotNotChosen(false);
    }
    setAppointmentDetails({
      ...appointmentDetails,
      timeSlot: e.target.value,
    });
  };

  const bookappointmentHandler = async () => {
    if (appointmentDetails.timeSlot === "") {
      setIsTimeSlotNotChosen(true);
      return;
    } else {
      const response = await fetch("http://localhost:8080/appointments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json;charset=utf-8",
          Authorization: `Bearer ${user.accessToken}`,
        },
        body: JSON.stringify(appointmentDetails),
      });
      if (response.status === 200) {
        const data = await response.text();
        console.log(data);
        bookApptModalHandler();
      } else {
        const data = await response.json();
        console.error(data);
        alert("Either the slot is already booked or not available");
      }
    }
  };


  return (
    <Modal open={modalOpen} >
      <Card className={classes.root} ref={cardComponentRef}>
        <CardHeader
          component="header"
          className={classes.header}
          title="Book an Appointment"
        />
        <CardContent component="form" className={classes.form}>
          <TextField
            disabled
            id="doctor-name"
            label="DoctorName"
            defaultValue={`${doctor.firstName} ${doctor.lastName}`}
          />
          <MuiPickersUtilsProvider utils={DateFnsUtils}>
            <KeyboardDatePicker
              disableToolbar
              variant="inline"
              format="dd/MM/yyyy"
              margin="normal"
              id="date-picker-inline"
              label="Date picker inline"
              value={appointmentDetails.appointmentDate}
              onChange={handleDateChange}
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </MuiPickersUtilsProvider>
          <FormControl className={classes.formControl}>
            <InputLabel shrink id="time-slot-dropdown-label">
              Timeslot
            </InputLabel>
            <Select
              labelId="time-slot-dropdown-label"
              id="demo-simple-select-placeholder-label"
              value={appointmentDetails.timeSlot}
              onChange={onTimeSlotChangeHandler}
              displayEmpty
            >
              <MenuItem value="" key={uuid()}>
                <em>None</em>
              </MenuItem>
              {timeSlots.map((timeSlot) => (
                <MenuItem value={timeSlot} key={uuid()}>
                  {timeSlot}
                </MenuItem>
              ))}
            </Select>
            {isTimeSlotNotChosen && (
              <FormHelperText error>Select a time slot</FormHelperText>
            )}
          </FormControl>
          <TextField
            id="medical-history"
            label="Medical History"
            multiline
            rows={4}
            value={appointmentDetails.priorMedicalHistory}
            onChange={(e) => {
              setAppointmentDetails({
                ...appointmentDetails,
                priorMedicalHistory: e.target.value,
              });
            }}
          />
          <TextField
            id="symptoms"
            label="Symptoms"
            multiline
            rows={4}
            value={appointmentDetails.symptoms}
            onChange={(e) => {
              setAppointmentDetails({
                ...appointmentDetails,
                symptoms: e.target.value,
              });
            }}
          />
          <Button
            className={classes.submitBtn}
            variant="contained"
            color="primary"
            onClick={bookappointmentHandler}
          >
            BOOK APPOINTMENT
          </Button>
        </CardContent>
      </Card>
    </Modal>
  );
}
