import { CardContent, CardHeader, Modal, Typography } from "@material-ui/core";
import React, {useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import Rating from "../../common/Rating";

const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 560,
    width: "content-fit",
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%,-50%)",
  },
  header: {
    backgroundColor: "purple",
    height: 70,
    display: "flex",
    alignItems: "center",
    padding: 11,
    color: "white",
  },
  cardContent: {
    "& > * ": {
      marginTop: theme.spacing(1),
    },
    "& > :first-child": {
      marginTop: 0,
    },
  },
  doctorName: {
    marginBottom: theme.spacing(1),
    fontWeight: "bold",
  },
}));

export default function DoctorDetails({
  doctor,
  modalOpen,
  viewDetailsModalHandler,
}) {
  const classes = useStyles();
  const cardComponentRef = useRef(null);

  const modalOnClickHandler = (e) => {
    if(cardComponentRef.current && !cardComponentRef.current.contains(e.target)){
      viewDetailsModalHandler();
    }
  }

  return (
    <Modal open={modalOpen} ariaHideApp={false} onClick={modalOnClickHandler}>
      <Card className={classes.root} ref={cardComponentRef}>
        <CardHeader component="header" className={classes.header} title="Doctor Details" />
        <CardContent component="article" className={classes.cardContent}>
          <Typography variant="body1" className={classes.doctorName}>
            Dr: {doctor.firstName} {doctor.lastName}
          </Typography>
          <Typography variant="body2">
            Total Experience: {doctor.totalYearsOfExp} years
          </Typography>
          <Typography variant="body2">
            Speciality: {doctor.speciality}
          </Typography>
          <Typography variant="body2">Date of Birth: {doctor.dob}</Typography>
          <Typography variant="body2">City: {doctor.address.city}</Typography>
          <Typography variant="body2">Email: {doctor.emailId}</Typography>
          <Typography variant="body2">Mobile: {doctor.mobile}</Typography>
          <Typography variant="body2" className="fx fx--ac">
            <span>Rating</span>: <Rating rating={doctor.rating} />
          </Typography>
        </CardContent>
      </Card>
    </Modal>
  );
}
