import React from "react";
import { useEffect, useState } from "react";
import Select from "@material-ui/core/Select";
import { makeStyles } from "@material-ui/core/styles";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Typography from "@material-ui/core/Typography";
import  uuid  from 'react-uuid';

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 180,
  },
  label : {
    textAlign : 'left'
  }
}));

const DoctorSpecialityDropDown = ({selectedSpecality,updateSpecialityHander}) => {
  const [specialityList, setSpecialityList] = useState([]);
  const classes = useStyles();
  const handleChange = (event) => {
    updateSpecialityHander(event.target.value);
  };

  useEffect(() => {
    const fetchData = async () => {
      const fetchData = await fetch("http://localhost:8080/doctors/speciality");
      const data = await fetchData.json();
      setSpecialityList(data);
      console.log(specialityList);
    };
    fetchData();
  }, []);
  return (
    <FormControl variant="filled" className={classes.formControl}>
      <Typography variant="subtitle1" className={classes.label}>Select Speciality: </Typography>
      <Select
        id="speciality-select"
        value={selectedSpecality}
        onChange={handleChange}
      >
         <MenuItem value="" key={uuid()}>None</MenuItem>
        {specialityList && specialityList.map((speciality) => (
        <MenuItem value={speciality} key={uuid()}>{speciality}</MenuItem>))}
      </Select>
    </FormControl>
  );
};

export default DoctorSpecialityDropDown;
