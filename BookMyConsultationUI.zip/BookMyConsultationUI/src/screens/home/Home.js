import React, { useContext, useState } from "react";

import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";

import Header from "../../common/header/Header";
import { useContextData } from "../../common/context/ContextProvider";
import DoctorList from "../doctorList/DoctorList";
import Appointment from "../appointment/Appointment";

export default function Home() {
  const { isLoggedIn } = useContextData();

  const [tab, setTab] = useState(0);

  const handleTabChange = (event, tabId) => {
    setTab(tabId);
  };

  return (
    <>
      <Header />
      <Tabs
        value={tab}
        onChange={handleTabChange}
        variant="fullWidth"
        indicatorColor="primary"
      >
        <Tab label="DOCTORS" />
        <Tab label="APPOINTMENT" />
      </Tabs>
      {!isLoggedIn && (
        <p style={{ textAlign: "center", marginTop: 40 }}>
          Login to see appointments
        </p>
      )}
      {tab === 0 && isLoggedIn &&  <DoctorList />}
      {tab === 1 && isLoggedIn && <Appointment />}
    </>
  );
}
