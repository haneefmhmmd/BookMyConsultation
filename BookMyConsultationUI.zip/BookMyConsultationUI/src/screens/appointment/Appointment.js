import { Button, Paper, Typography } from "@material-ui/core";

import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import RateAppointment from "./RateAppointment";
import { useContextData } from "../../common/context/ContextProvider";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: "16px",
    padding: 20,
    "& h6": {
      marginBottom: 16,
      fontWeight: "normal",
    },
    "& p": {
      marginTop: 8,
    },
    "& button": {
      marginTop: 24,
    },
  },
}));

export default function Appointment() {
  const [apptList, setApptList] = useState([]);
  const classes = useStyles();
  const { user } = useContextData();
  const [apptModalStatus, setApptModalStatus] = useState({
    appt: null,
    state: false,
  });

  useEffect(() => {
    fetch(`http://localhost:8080/users/${user.emailAddress}/appointments`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${user.accessToken}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        setApptList(data);
      });
  }, []);

  return (
    <section>
      {apptList.length === 0 && (
        <p style={{ textAlign: "center", marginTop: 40 }}>
          No Appoinments Present!
        </p>
      )}
      {apptList &&
        apptList.map((appt) => (
          <Paper className={classes.root} key={appt.appointmentId}>
            <Typography variant="h6">Dr: {appt.doctorName}</Typography>
            <Typography variant="body1">
              Date: {appt.appointmentDate}
            </Typography>
            <Typography variant="body1">Symptoms: {appt.symptoms}</Typography>
            <Typography variant="body1">
              priorMedicalHistory: {appt.priorMedicalHistory}
            </Typography>
            <Button
              variant="contained"
              color="primary"
              onClick={() => {
                setApptModalStatus({ appt: appt, state: true });
              }}
            >
              RATE APPOINTMENT
            </Button>
          </Paper>
        ))}
      {apptModalStatus.state && (
        <RateAppointment
          appt={apptModalStatus.appt}
          modalOpen={apptModalStatus.state}
          modalHandler={() => {
            setApptModalStatus({ appt: null, state: false });
          }}
        />
      )}
    </section>
  );
}
