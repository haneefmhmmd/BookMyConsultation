import React, { useRef, useState } from "react";
import {
  Button,
  CardContent,
  CardHeader,
  Modal,
  Typography,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import TextField from "@material-ui/core/TextField";
import { useContextData } from '../../common/context/ContextProvider';

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 560,
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%,-50%)",
  },
  header: {
    backgroundColor: "purple",
    height: 70,
    display: "flex",
    alignItems: "center",
    padding: 11,
    color: "white",
  },
  cardContent: {
    "& > * ": {
      marginTop: theme.spacing(2),
    },
    "& > :first-child": {
      marginTop: 0,
    },
  },
  ratingContainer: {
    marginLeft: 8,
    "& > *": {
      cursor: "pointer",
    },
  },
  errorText: {
    color: "red",
  },
  submitBtn: {
    marginTop: 24,
  },
}));

export default function RateAppointment({ appt, modalOpen, modalHandler }) {
  const classes = useStyles();
  const cardComponentRef = useRef(null);
  const starsCount = [1, 2, 3, 4, 5];
  const {user} = useContextData();

  const [ratingData, setRatingData] = useState({
    appointmentId: appt.appointmentId,
    doctorId: appt.doctorId,
    rating: "",
    comments: "",
  });

  const [isRatingNotSelected, setIsRatingNotSelected] = useState(null);

  const modalOnClickHandler = (e) => {
    if (
      cardComponentRef.current &&
      !cardComponentRef.current.contains(e.target)
    ) {
      modalHandler();
    }
  };

  const starMouseOverHandler = (e) => {
    const clickedStarNumber = e.currentTarget.id.replace("star-", "");
    const stars = document.querySelectorAll(".rating-stars");

    stars.forEach((star) => {
      if (star.id.replace("star-", "") <= clickedStarNumber) {
        star.setAttribute("fill", "#FFB400");
      } else {
        star.setAttribute("fill", "#d9e1ee");
      }
    });
    setRatingData({ ...ratingData, rating: clickedStarNumber });
    setIsRatingNotSelected(false);
  };

  const ratingsSubmitHandler = async (e) => {
    e.preventDefault();

    if (ratingData.rating !== 0 && ratingData.rating.length > 0) {
      const res = await fetch("http://localhost:8080/ratings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json;charset=utf-8",
          "Authorization": `Bearer ${user.accessToken}`,
        },
        body: JSON.stringify(ratingData),
      });
      console.log(res);
      if (res.status === 200) {
        console.log("Done");
        modalHandler();
      }
    } else {
      setIsRatingNotSelected(true);
    }
  };

  return (
    <Modal open={modalOpen} ariaHideApp={false} onClick={modalOnClickHandler}>
      <Card className={classes.root} ref={cardComponentRef}>
        <CardHeader className={classes.header} title="Rate an Appointment" />
        <CardContent component="form" className={classes.cardContent}>
          <TextField
            id="comments"
            label="Comments"
            multiline
            minRows={4}
            maxRows={4}
            value={ratingData.comments}
            onChange={(e) => {
              setRatingData({
                ...ratingData,
                comments: e.target.value,
              });
            }}
          />
          <div className="fx fx--ac">
            <Typography variant="body1" component="span">
              Rating :
            </Typography>
            <div className={`fx fx--ac ${classes.ratingContainer}`}>
              {starsCount.map((starCount) => (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="17"
                  fill="#d9e1ee"
                  id={`star-${starCount}`}
                  className="rating-stars"
                  onMouseEnter={starMouseOverHandler}
                  key={`star-${starCount}`}
                >
                  <path
                    fillRule="evenodd"
                    d="M7.911 2.504a.864.864 0 00-.68.466L5.697 6.009l-2.92.29a.85.85 0 00-.725.559l-.027.086a.86.86 0 00.228.815l2.42 2.397-.895 3.256a.86.86 0 00.288.892l.074.054c.254.165.58.185.855.047l3.004-1.488 3.011 1.491c.3.151.663.112.926-.102l.068-.061c.214-.215.3-.53.22-.827l-.896-3.26 2.418-2.397a.853.853 0 00.202-.901l-.035-.083a.853.853 0 00-.698-.477l-2.913-.289-1.534-3.039a.865.865 0 00-.77-.472l-.087.004z"
                    clipRule="evenodd"
                  />
                </svg>
              ))}
            </div>
          </div>
          {isRatingNotSelected && (
            <Typography
              variant="caption"
              display="block"
              className={classes.errorText}
              gutterBottom
            >
              Select a rating
            </Typography>
          )}
          <Button
            variant="contained"
            color="primary"
            onClick={ratingsSubmitHandler}
            className={classes.submitBtn}
          >
            RATE APPOINTMENT
          </Button>
        </CardContent>
      </Card>
    </Modal>
  );
}
