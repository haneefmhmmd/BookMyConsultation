import React, { useState } from "react";
import FormControl from "@material-ui/core/FormControl";
import {
  InputLabel,
  Input,
  makeStyles,
  FormHelperText,
} from "@material-ui/core";
import Button from "@material-ui/core/Button";
import { useContextData } from '../../common/context/ContextProvider';

const useStyles = makeStyles({
  root: {
    display: "flex",
    flexDirection: "column",
    padding: "16px 80px",
  },
  button: {
    marginTop: 40,
  },
});

export default function Login({modalCloseHandler}) {
  const classes = useStyles();
  const { setIsLoggedIn, setUser } = useContextData();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isEmailValid, setIsEmailValid] = useState({
    isValid: "",
    message: "",
  });
  const [isPasswordValid, setIsPasswordValid] = useState({
    isValid: "",
    message: "",
  });
  const inputChangeHandler = (e) => {
    if (e.target.name === "email") {
      setEmail(e.target.value);
    } else if (e.target.name === "password") {
      setPassword(e.target.value);
    }
    if (e.target.name === "email" && isEmailValid.isValid === false) {
      setIsEmailValid({ isValid: true, message: "" });
    }
  };
  const validateEmail = () => {
    if (email.length === 0) {
      setIsEmailValid({
        isValid: false,
        message: "Please fill out this field",
      });
      return false;
    }

    const emailValidityRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    if (emailValidityRegex.test(email) === false) {
      setIsEmailValid({ isValid: false, message: "Enter valid Email" });
      return false;
    }
    if (isEmailValid.isValid === false) {
      setIsEmailValid({ isValid: true, message: "" });
    }
    return true;
  };
  const validatePassword = () => {
    if (password.length === 0) {
      setIsPasswordValid({
        isValid: false,
        message: "Please fill out this field",
      });
      return false;
    }
    if (isPasswordValid.isValid === false) {
      setIsPasswordValid({ isValid: true, message: "" });
    }
    return true;
  };

  const onSubmitHandler = async (e) => {
    e.preventDefault();
    if (validateEmail() && validatePassword()) {
      const loginRequest = await fetch("http://localhost:8080/auth/login", {
        method: "POST",
        headers: {
          Authorization: "Basic " + btoa(email + ":" + password),
        },
      });
      const loginResponse = await loginRequest.json();
      if (loginRequest.status === 200) {
        window.accessToken = loginResponse.accessToken;
        setUser(loginResponse);
        setIsLoggedIn(true);
        modalCloseHandler();
      }else{
        console.error("Error while logging in");
      }
    }
  };
  return (
    <form className={classes.root}>
      <FormControl margin="dense" error={isEmailValid.isValid === false} required>
        <InputLabel htmlFor="login-email">Email</InputLabel>
        <Input
          id="login-email"
          aria-describedby="email-validation-text"
          value={email}
          name="email"
          onChange={inputChangeHandler}
        />
        <FormHelperText
          error={isEmailValid.isValid === false}
          id="email-validation-text"
        >
          {isEmailValid.message}
        </FormHelperText>
      </FormControl>
      <FormControl margin="dense" error={isPasswordValid.isValid === false} required>
        <InputLabel htmlFor="login-passwd">Password</InputLabel>
        <Input
          id="login-passwd"
          name="password"
          type="password"
          value={password}
          aria-describedby="passwd-validation-text"
          onChange={inputChangeHandler}
        />
        <FormHelperText
          error={isPasswordValid.isValid === false}
          id="passwd-validation-text"
        >
          {isPasswordValid.message}
        </FormHelperText>
      </FormControl>
      <Button
        variant="contained"
        color="primary"
        className={classes.button}
        onClick={onSubmitHandler}
        type="submit"
      >
        Login
      </Button>
    </form>
  );
}
