import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Alert from '@material-ui/lab/Alert';

const useStyles = makeStyles((theme) => ({
  root: {
    width: 'calc(100% - 40px)',
    position : "fixed",
    top: 40,
    left : '50%',
    transform: 'translateX(-50%)',
},
}));

export default function Toast({type, message}) {
    const classes = useStyles();
    return (
      <div className={classes.root}>
        <Alert severity={type}>
          {message}
        </Alert>
      </div>
    );
}
