import React, { createContext, useState, useContext } from "react";

const Context = createContext();

const ContextProvider = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState({});
  return (
    <Context.Provider value={{ isLoggedIn, setIsLoggedIn,user,setUser }}>
      {children}
    </Context.Provider>
  );
};

export const useContextData = () => {
    const context = useContext(Context);
    if(context === undefined)
        throw new Error('useTemplate must be used within TemplateProvider');
    return context;
}

export default ContextProvider;
