import React, { useState } from "react";
import Modal from "react-modal";

import "./Header.css";
import logo from "../../assets/logo.jpeg";

import Button from "@material-ui/core/Button";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Login from "../../screens/login/Login";
import Register from '../../screens/register/Register';
import { useContextData } from '../context/ContextProvider';
import { Typography } from "@material-ui/core";



export default function Header() {

  const{isLoggedIn,setIsLoggedIn} = useContextData();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tab, setTab] = useState(0);
  const handleTabChange = (event, newValue) => {
    setTab(newValue);
  };
  const modalCloseHandler = () => {
    setIsModalOpen(false);
  };

  const handleLogout = async () => {
    const logout = await fetch("http://localhost:8080/auth/logout", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${window.accessToken}`,
      },
    });
    window.accessToken = null;
    if(logout.status === 200){
      setIsLoggedIn(false);
    }
    console.error("Error while logging out!");
  };

  return (
    <header className="header">
      <img src={logo} alt="Header Logo" height="35" />
      <Typography variant="h1">Doctor Finder</Typography>
      {isLoggedIn && (
        <Button variant="contained" color="secondary" onClick={handleLogout}>
          Logout
        </Button>
      )}
      {!isLoggedIn && (
        <Button
          variant="contained"
          color="primary"
          onClick={() => {
            setIsModalOpen(true);
          }}
        >
          Login
        </Button>
      )}
      <Modal
        isOpen={isModalOpen}
        style={{ content: { padding: 0, maxWidth: 375, margin: "0 auto" } }}
        ariaHideApp={false} 
      >
        <header className="modal__header">
          <h2>Authentication</h2>
        </header>
        <Tabs value={tab} onChange={handleTabChange}>
          <Tab label="Login" />
          <Tab label="Register" />
        </Tabs>
        {tab === 0 && <Login modalCloseHandler={modalCloseHandler} />}
        {tab === 1 && <Register modalCloseHandler={modalCloseHandler} />}
      </Modal>
    </header>
  );
}
