import React from "react";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles(() => ({
  stars: {
    backgroundSize: 14,
    height: 14,
    backgroundRepeat: "repeat-x",
  },
  reviewStar: {
    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='17' fill='%23d9e1ee' viewBox='0 0 16 17' %3E%3Cpath fill-rule='evenodd' d='M7.911 2.504c-.289.03-.546.204-.68.466L5.697 6.009l-2.92.29c-.325.026-.611.245-.725.559l-.027.086c-.072.29.013.601.228.815l2.42 2.397-.895 3.256c-.088.331.025.679.288.892l.074.054c.254.165.58.185.855.047l3.004-1.488 3.011 1.491c.3.151.663.112.926-.102l.068-.061c.214-.215.3-.53.22-.827l-.896-3.26 2.418-2.397c.238-.235.317-.587.202-.901l-.035-.083c-.131-.27-.396-.452-.698-.477l-2.913-.289-1.534-3.039c-.149-.29-.445-.472-.77-.472l-.087.004z' clip-rule='evenodd'%3E%3C/path%3E%3C/svg%3E")`,
    width: 70,
    display: "inline-block",
    overflow: "hidden",
    margin: "0 5px",
  },
  ratedStar: {
    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='17' fill='%23FFB400' viewBox='0 0 16 17' %3E%3Cpath fill-rule='evenodd' d='M7.911 2.504c-.289.03-.546.204-.68.466L5.697 6.009l-2.92.29c-.325.026-.611.245-.725.559l-.027.086c-.072.29.013.601.228.815l2.42 2.397-.895 3.256c-.088.331.025.679.288.892l.074.054c.254.165.58.185.855.047l3.004-1.488 3.011 1.491c.3.151.663.112.926-.102l.068-.061c.214-.215.3-.53.22-.827l-.896-3.26 2.418-2.397c.238-.235.317-.587.202-.901l-.035-.083c-.131-.27-.396-.452-.698-.477l-2.913-.289-1.534-3.039c-.149-.29-.445-.472-.77-.472l-.087.004z' clip-rule='evenodd'%3E%3C/path%3E%3C/svg%3E")`,
    display: "block",
  },
}));

export default function Rating({ rating }) {
  const classes = useStyles();
  const starYellowWidth = rating * 20 + '%';
  return (
    <span className={`${classes.stars} ${classes.reviewStar}`}>
      <span
        className={`${classes.stars} ${classes.ratedStar}`}
        style={{ width: starYellowWidth }}
      ></span>
    </span>
  );
}
