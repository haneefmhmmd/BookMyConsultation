import React, { useState } from "react";
import FormControl from "@material-ui/core/FormControl";
import {
  InputLabel,
  Input,
  makeStyles,
  FormHelperText,
} from "@material-ui/core";
import Button from "@material-ui/core/Button";

const useStyles = makeStyles({
    root: {
      display: "flex",
      flexDirection: "column",
      padding: "16px 80px",
    },
    button: {
      marginTop: 40,
    },
  });

export default function Form({fieldList,submitButtonText,onSubmitHandler}) {
    const classes = useStyles();
    const inputs = fieldList;
    // const [inputs, setInputs] = useState(fieldList);
    const [validationError, setValidationError] = useState({
        element: null,
        message: "",
      });
      const inputChangeHandler = (e) => {
        if (validationError.element === e.target.name) {
          setValidationError({ element: null, message: "" });
        }
      };
      const isInputFilled = (input) => {
        if(input.value.length === 0){
          setValidationError({
            element: input.name,
            message: "Please fill out this field",
          });
          return false;
        }
        return true;
      }
      const validateEmail = (input) => {
        const emailValidityRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        console.log(input);
        if (emailValidityRegex.test(input.value) === false) {
          console.log("email not valid");
          setValidationError({ element: input.name, message: "Enter valid Email" });
          return false;
        }
        return true;
      };
      const isNumberValid = (input)=>{
        const numberValidityRegex = /^[0-9]{10}$/;
        if (numberValidityRegex.test(input.value) === false) {
          setValidationError({ element: input.name, message: "Phone Number should contain only digits and should have 10 numbers" });
          return false;
        }
        return true;
      };
      const setInputsValue = ()=>{
        inputs.forEach((input) => {
          input.value = document.getElementById(input.name).value;
        });
      }
      const validateInput = (input)=>{
        if(!isInputFilled(input)){
          return false;
        }
        if(input.name === "emailId" && !validateEmail(input)){
          return false;
        }
        if(input.type ==="tel" && !isNumberValid(input)){
          return false;
        }
        return true;
      };

      const onSubmitBtnClickHandler = async (e) => {
        e.preventDefault();
        setInputsValue();
        const isInputsValid = inputs.every((input) => validateInput(input));
        if(isInputsValid){
          onSubmitHandler(inputs);
        }else{
            console.error("Error while validating form");
        }
      };
  return (
    <form className={classes.root}>
        {inputs.map((input) => (
            <FormControl
            margin="dense"
            error={validationError.element === input.name}
            required
            key={input.name}
          >
            <InputLabel htmlFor={input.name}>{input.label}</InputLabel>
            <Input
              id={input.name}
              aria-describedby={`${input.name}-validation-text`}
              name={input.name}
              aria-label = {input.label}
              onChange={inputChangeHandler}
              type={input.type}
            />
            <FormHelperText
              error={validationError.element === input.name}
              id={`${input.name}-validation-text`}
            >
              {validationError.element===input.name ? validationError.message:""}
            </FormHelperText>
          </FormControl>
        ))}
      <Button
        variant="contained"
        color="primary"
        className={classes.button}
        type="submit"
        onClick={onSubmitBtnClickHandler}
      >        
        {submitButtonText}
      </Button>
    </form>
  )
}
